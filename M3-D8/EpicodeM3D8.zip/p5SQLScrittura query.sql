


/* 1) Visualizzare i prodotti che sono stati venduti e quando. E creazione di VIEW */

Create VIEW FC_ViewProduct as 

SELECT p.ProductKey, p.ProductName AS Product, sc.SubcategoryName AS Subcategory, s.SalesID, s.SaleDate, s.ProductNames, s.totalsale
FROM Product p
INNER JOIN Subcategory sc
ON p.CategoryKey = sc.CategoryKey
INNER JOIN Sale s
ON sc.CategoryKey = s.CategoryKey


/* 2) Visualizzare i prodotti pi� venduti utilizzando la VIEW */

select SELECT  ProductKey, SubcategoryName AS Subcategory, sum(s.TotalSales)
from FC_ViewProduct
group by ProductKey,  SubcategoryName
order by ProductKey, sum(s.TotalSales) as TotalSale


/* 3) Visualizzare i dipendenti che non hanno effettuato nessuna vendita*/

SELECT e.EmployeeKey, e.LastName, e.FirstName, e.StoreKey, e.HireDate, e.CurrentFlag, s.SalesID
FROM Employee e
LEFT JOIN Sale s
ON e.EmployeeKey = s.EmployeeKey
WHERE s.EmployeeKey is null and e.CurrentFlag=1


/* 4) Visualizzare dipendente che ha emesso pi� fidelity card */

SELECT EmployeeKey, LastName, FirstName, Gender, StoreKey, HireDate, CurrentFlag=1
FROM Employee 
ORDER BY EmployeeKey


/* 5) Ordinare i prodotti visualizzando prima con pi� disponibilit� in magazzino */

SELECT ProductKey, ProductName, InStock
FROM Product
GROUP BY InStock, ProductKey, ProductName
ORDER BY InStock DESC

/* 6) Visualizzare l'impiegato che ha venduto di pi� */

SELECT 
	CONCAT(e.lastName, ' ', e.FirstName) AS EmployeeName, s.EmployeeKey, sum(s.TotalSales) AS TotalSale  
FROM Sale s
INNER JOIN Employee e
ON s.EmployeeKey = e.EmployeeKey
GROUP BY  s.EmployeeKey, CONCAT(e.lastName, ' ', e.FirstName)


/* 7) Il negozio che ha venduto di pi� */

SELECT s.StoreKey,  sum(s.TotalSales) AS TotalSale
FROM  sale s
GROUP BY s.StoreKey


/* 8) Margine di profitto in percentuale e relativo importo, tra il prezzo di acquisto del prodotto e il prezzo di vendita */ 

SELECT ProductKey, ProductName,((unitsaleprice-UnitCost)/unitsaleprice)*100 AS RevenuePerc, (unitsaleprice-unitcost) AS Revenue
FROM Product


/* 9) Impiegati il cui contratto � terminato entro l'anno 2010 */

SELECT * 
FROM Employee
WHERE year(EndDate)<=2010 and CurrentFlag=0

/* 10) Quanti giorno sono passati dall'ultima vendita per impiegato che l'ha effettuata */

SELECT DISTINCT e.EmployeeKey, CONCAT(e.firstname, ' ',e.lastname) AS EmplyeeName, DATEDIFF(dd, SaleDate , GETDATE()) AS NoSalesDays 
FROM Sale s
INNER JOIN Employee e
ON s.EmployeeKey = e.EmployeeKey

WHERE s.SaleDate IN (
						SELECT MAX(s2.saledate)
						FROM Sale s2
						WHERE s.EmployeeKey= s2.EmployeeKey)
GROUP BY e.EmployeeKey,e.FirstName, e.LastName, s.SaleDate










